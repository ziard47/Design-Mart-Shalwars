<?php
  //adding a new record to the table product in the db_ad4850 database

  //1st lets connect to the database server

  require("db_connection.php");

  //get the values from the form (add_product_1.php) and display
  echo "<pre>";
  print_r($_REQUEST);
  echo "</pre>";


 ?>
